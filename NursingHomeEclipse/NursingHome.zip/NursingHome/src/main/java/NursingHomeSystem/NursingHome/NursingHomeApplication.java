package NursingHomeSystem.NursingHome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NursingHomeApplication {

	public static void main(String[] args) {
		SpringApplication.run(NursingHomeApplication.class, args);
	}

}
