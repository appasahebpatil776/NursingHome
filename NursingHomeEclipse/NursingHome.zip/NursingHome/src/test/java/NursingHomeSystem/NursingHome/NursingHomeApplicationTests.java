package NursingHomeSystem.NursingHome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NursingHomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
